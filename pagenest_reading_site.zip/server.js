const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

if (!ADMIN_TOKEN) {
  console.error("Set ADMIN_TOKEN before starting the server.");
  process.exit(1);
}

// If deployed behind a trusted reverse proxy, configure this explicitly.
// Example: app.set("trust proxy", 1); Only do this when you know your proxy setup.
const BAN_FILE = path.join(__dirname, "bans.json");

app.use(express.json({ limit: "20kb" }));

function readBans() {
  try {
    return JSON.parse(fs.readFileSync(BAN_FILE, "utf8"));
  } catch {
    return {};
  }
}
function writeBans(bans) {
  fs.writeFileSync(BAN_FILE + ".tmp", JSON.stringify(bans, null, 2));
  fs.renameSync(BAN_FILE + ".tmp", BAN_FILE);
}
function getClientIp(req) {
  // req.ip is supplied by Express. Do not trust arbitrary X-Forwarded-For headers.
  return req.ip || req.socket.remoteAddress || "unknown";
}
function normalizeIp(ip) {
  return String(ip || "").trim().replace(/^::ffff:/, "");
}
function isAdmin(req) {
  const header = req.get("authorization") || "";
  return header === `Bearer ${ADMIN_TOKEN}`;
}

// IP ban middleware applies to the website and its APIs.
app.use((req, res, next) => {
  const ip = normalizeIp(getClientIp(req));
  const bans = readBans();
  const ban = bans[ip];

  if (ban) {
    return res.status(403).send(`Access denied. This IP address is banned. Reason: ${ban.reason || "No reason provided"}`);
  }
  next();
});

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/books", (req, res) => {
  res.json([
    {
      id: "the-little-observatory",
      title: "The Little Observatory",
      author: "A. Rowan",
      category: "Adventure",
      description: "A short original story about curiosity and the night sky.",
      content: `Mira kept a notebook beside her window. Each evening, she wrote down one thing she had noticed about the sky. One night, a tiny moving light crossed the stars. She checked her notes, waited, and watched again. It was not magic—just a satellite—but discovering it made the universe feel closer.`
    },
    {
      id: "the-paper-bridge",
      title: "The Paper Bridge",
      author: "J. Vale",
      category: "Short story",
      description: "A story about patience, practice, and building something together.",
      content: `The class had one challenge: build a bridge from paper. The first design folded under a coin. The second held two. Instead of giving up, the students tested small changes and compared results. By the end of the afternoon, their bridge held a stack of books—and everyone had learned that careful experiments can turn a weak idea into a strong one.`
    },
    {
      id: "notes-from-the-garden",
      title: "Notes from the Garden",
      author: "M. Ellis",
      category: "Nature",
      description: "A calm reading about noticing small changes in nature.",
      content: `The garden changed a little every day. A new leaf appeared near the fence; a bee visited the lavender; rain left bright beads on the soil. None of these things happened loudly. You had to slow down to notice them. The gardener began keeping a journal, and soon an ordinary corner of the yard became a world worth exploring.`
    }
  ]);
});

// Admin endpoints. Send: Authorization: Bearer YOUR_ADMIN_TOKEN
app.get("/admin/bans", (req, res) => {
  if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
  res.json(readBans());
});

app.post("/admin/ban", (req, res) => {
  if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });

  const ip = normalizeIp(req.body.ip);
  const reason = String(req.body.reason || "No reason provided").slice(0, 200);

  // Basic validation; supports IPv4 and IPv6 text forms.
  if (!ip || ip.length > 45 || !/^[0-9a-fA-F:.]+$/.test(ip)) {
    return res.status(400).json({ error: "Enter a valid IP address." });
  }

  const bans = readBans();
  bans[ip] = { reason, bannedAt: new Date().toISOString() };
  writeBans(bans);
  res.json({ success: true, ip });
});

app.post("/admin/unban", (req, res) => {
  if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });

  const ip = normalizeIp(req.body.ip);
  const bans = readBans();
  if (!bans[ip]) return res.status(404).json({ error: "That IP is not banned." });

  delete bans[ip];
  writeBans(bans);
  res.json({ success: true, ip });
});

app.listen(PORT, () => {
  console.log(`Reading site running at http://localhost:${PORT}`);
});