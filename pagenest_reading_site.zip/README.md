# PageNest — Reading website + IP ban system

## Features
- Responsive reading website with a searchable sample library
- Reader view for each story
- Server-side IP ban checks (banned addresses receive HTTP 403)
- Admin endpoints to list, ban, and unban IP addresses
- Ban data persists in `bans.json`

## Run locally
1. Install Node.js (18 or newer).
2. In this folder, install dependencies:
   ```bash
   npm install
   ```
3. Set a private admin token, then start the server.

   Linux/macOS:
   ```bash
   ADMIN_TOKEN="use-a-long-random-secret" npm start
   ```

   Windows PowerShell:
   ```powershell
   $env:ADMIN_TOKEN="use-a-long-random-secret"
   npm start
   ```
4. Open `http://localhost:3000`.

## Admin API
Use the secret token as a Bearer token in the `Authorization` header.

List bans:
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" http://localhost:3000/admin/bans
```

Ban an IP:
```bash
curl -X POST http://localhost:3000/admin/ban \\
  -H "Authorization: Bearer YOUR_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"ip":"203.0.113.10","reason":"Repeated spam"}'
```

Unban an IP:
```bash
curl -X POST http://localhost:3000/admin/unban \\
  -H "Authorization: Bearer YOUR_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"ip":"203.0.113.10"}'
```

## Important deployment notes
- The IP ban is enforced by the server, not by browser JavaScript. A static-only host cannot enforce it.
- Use HTTPS when deployed. Keep `ADMIN_TOKEN` private; never put it in frontend code or share it.
- This starter does not include a visual admin dashboard. Admin actions use protected API endpoints.
- By default, Express uses the direct network peer address. If your host uses a reverse proxy, configure `trust proxy` only for the exact trusted proxy setup; trusting arbitrary forwarded headers can let visitors spoof their IP.
- IP addresses are personal data in many jurisdictions. Tell visitors what you collect, limit access to the ban file, and keep only what you need.
- IP bans can affect multiple people on shared Wi-Fi or mobile carrier networks, and changing networks can change a visitor's IP.
